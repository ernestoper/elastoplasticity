global dimension sigmay1 sigmay2 h1 h2 mu mu_times_2 lambda C 
global fglobal
global STEMAelastic DirichletKnoten freieKnoten maske B W ...
   freie2DKnoten 
global Koordinaten Elemente Neumann Dirichlet 
global fv gv %mesh + time step invariants
global tolerance 
global yield_type %singleyield of multiyield
global Rglobal Areaglobal
global problem;
global mu_times_2
global theta
global condestA N hysteresis_u hysteresis_g 

